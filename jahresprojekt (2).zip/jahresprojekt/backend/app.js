const express = require('express');
const http = require('http')
const fs = require('fs')
require('dotenv').config();
const app = express();
const port = process.env.PORT; //Port for the backend to listen on
const helper = require('./helper')
const morgan = require('morgan')

const winston = require('./winston');
const {generateUserId} = require("./helper");
const morganformat = ':method on :url by :remote-addr with status code :status took :response-time ms';
app.use(morgan(morganformat, { stream: winston.stream }));

app.post('/createUser', async (req, res) =>
{
   try{
       await helper.createUser( req.query.Lastname,req.query.Firstname, req.query.Datum, req.query.Password, req.query.SoZi)
       res.status(200)
       res.send("User wurde erstellt.");
       console.log(req.query.id)
   }
   catch(err){
       res.status(500)
       res.send("User erstellen hat nicht funktoniert.")
   }
})

app.delete('/deleteUser', async (req, res)=>
{
   try{
       await helper.deleteUser(req.query.id)
       res.status(200)
       res.send("User wurde gelöscht")
       }
   catch (err){
       res.status(500)
       res.send("User löschen hat nicht funktoniert.")
   }
})

app.get('/getAllUser', async (req,res) => {
    try{
        let result = await helper.getAllUser()
        res.status(200)
        let response = {
            message: "Alle User:",
            data: result
        }
        res.send(response)
    }
    catch (err)
    {
        res.status(500)
        res.send("Konnte nicht alle User auswählen")
    }
})


app.patch('/UpdateUserById', async (req,res) => {
    try{
        let result = await helper.UpdateUserById( req.query.c_firstname, req.query.c_lastna,e, req.query.birthday, req.query.c_country, req.query)
        res.status(200)
        let response = {
            message: "User geändert:",
            data: result
        }
        res.send(response)
    }
    catch (err)
    {
        res.status(500)
        res.send("Konnte User nicht auswählen")
    }
})
let server = http.createServer(app);
server.listen(port,()=>{
    console.log(`http server listining on Port: ${port}`)


    let result = generateUserId();
})

