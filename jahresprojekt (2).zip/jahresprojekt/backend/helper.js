const dbHelper = require('./dbhelper')

//Rest API
async function createUser(lastname, firstname, datum, password){
    await dbHelper.makeDbQuery('INSERT INTO user values(NULL,?,?,?,?,?)',[lastname, firstname,datum, password, soZi])
}

async function checkUserExisting(userpassword, password){
    await dbHelper.makeDbQuery('SELECT PASSWORD, USERNAME from User where USERNAME=?'[])
}

async function deleteUser(id)
{
    try{
        await dbHelper.makeDbQuery('DELETE FROM user where PID=?', [id])
    }catch (e){
        console.log(e)
    }
}

async function getAllUser()
{
    try{
        let result = await dbHelper.makeDbQuery(`SELECT * FROM user`)
        return result
    }
    catch (e){
        console.log(e)
    }
}

async  function UpdateUserById(idc_costumer,c_firstname, c_lastname, c_birthday, c_country,c_state, c_streetname, c_postalcode, c_additonaladress, c_sozi, companyId, c_number, c_email, c_password )
{
    try{
        let result = await dbHelper.makeDbQuery(`UPDATE User set c_firstname, c_lastname, c_birthday, c_country,c_state, c_streetname, c_postalcode, c_additonaladress, c_sozi, companyId, c_number, c_email, c_password  where idc_costumer = ?`, [ c_firstname, c_lastname, c_birthday, c_country,c_state, c_streetname, c_postalcode, c_additonaladress, c_sozi, companyId, c_number, c_email, c_password])
        return result
    }
    catch (e){
        console.log(e)
    }

}

async function generateUserId(){
    let result = Math.floor(10000000 + Math.random() * 90000000);
    return result
}

async function getDates(){
    try{
        let result = await dbHelper.makeDbQuery(`UPDATE User set c_firstname, c_lastname, c_birthday, c_country,c_state, c_streetname, c_postalcode, c_additonaladress, c_sozi, companyId, c_number, c_email, c_password  where idc_costumer = ?`, [ c_firstname, c_lastname, c_birthday, c_country,c_state, c_streetname, c_postalcode, c_additonaladress, c_sozi, companyId, c_number, c_email, c_password])
        return result
    }
    catch (e){
        console.log(e)
    }
}

//End Rest API


//Export Module
module.exports = {
    createUser,
    deleteUser,
    getAllUser,
    UpdateUserById,
    generateUserId,
}
